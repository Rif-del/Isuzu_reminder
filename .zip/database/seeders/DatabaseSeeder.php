<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Kosongkan dulu, seeder dijalankan manual nanti via shell
    }
}
